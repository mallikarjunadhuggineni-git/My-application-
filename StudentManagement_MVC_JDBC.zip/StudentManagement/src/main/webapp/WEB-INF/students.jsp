<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ page import="java.util.List" %>
<%@ page import="com.student.model.Student" %>
<%!
    private String esc(Object value) {
        if (value == null) return "";
        return value.toString().replace("&", "&amp;").replace("<", "&lt;")
                .replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&#x27;");
    }
%>
<%
    List<Student> students = (List<Student>) request.getAttribute("students");
    String ctx = request.getContextPath();
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Management System</title>
    <link rel="stylesheet" href="<%= ctx %>/style.css">
</head>
<body>
<main class="container">
    <header>
        <div class="eyebrow">JAVA MVC • JDBC • MYSQL</div>
        <h1>Student Management</h1>
        <p class="subtitle">Add, view, update, and delete student records.</p>
    </header>

    <section class="card">
        <h2>Add a student</h2>
        <form action="<%= ctx %>/students" method="post" class="form-grid">
            <input type="hidden" name="action" value="add">
            <label>Full name<input name="name" maxlength="100" required placeholder="e.g. Ravi Kumar"></label>
            <label>Email<input name="email" type="email" maxlength="100" required placeholder="name@example.com"></label>
            <label>Course<input name="course" maxlength="100" required placeholder="e.g. Java"></label>
            <button type="submit" class="primary">Add student</button>
        </form>
    </section>

    <section class="card">
        <div class="table-heading">
            <div><h2>Student records</h2><p class="muted">Total: <%= students == null ? 0 : students.size() %></p></div>
            <a class="refresh" href="<%= ctx %>/students">Refresh</a>
        </div>
        <div class="table-wrap">
        <table>
            <thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Course</th><th>Actions</th></tr></thead>
            <tbody>
            <% if (students == null || students.isEmpty()) { %>
                <tr><td colspan="5" class="empty">No student records yet. Add one above.</td></tr>
            <% } else { for (Student s : students) { %>
                <tr>
                    <td><%= s.getId() %></td>
                    <td><%= esc(s.getName()) %></td>
                    <td><%= esc(s.getEmail()) %></td>
                    <td><%= esc(s.getCourse()) %></td>
                    <td class="actions">
                        <details>
                            <summary class="edit">Edit</summary>
                            <form action="<%= ctx %>/students" method="post" class="edit-form">
                                <input type="hidden" name="action" value="update">
                                <input type="hidden" name="id" value="<%= s.getId() %>">
                                <input name="name" value="<%= esc(s.getName()) %>" required aria-label="Name">
                                <input name="email" type="email" value="<%= esc(s.getEmail()) %>" required aria-label="Email">
                                <input name="course" value="<%= esc(s.getCourse()) %>" required aria-label="Course">
                                <button class="primary" type="submit">Save</button>
                            </form>
                        </details>
                        <form action="<%= ctx %>/students" method="post" onsubmit="return confirm('Delete this student?');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<%= s.getId() %>">
                            <button class="danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <% } } %>
            </tbody>
        </table>
        </div>
    </section>
    <footer>Built with Java Servlet, MVC, JDBC, and MySQL</footer>
</main>
</body>
</html>
